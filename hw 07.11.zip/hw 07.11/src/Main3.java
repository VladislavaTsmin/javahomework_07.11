public class Main3 {
    public static void main(String[] args){
        String str = "AAAABBBCCCDDEG";
        int count = 1;
        char ch = str.charAt(0);
        StringBuilder sb = new StringBuilder();
        for (int i = 1; i < str.length(); i++) {
            if (str.charAt(i) == ch){
                count++;
            }else {
                sb.append(ch);
                if (count > 1){
                    sb.append(count);
                }
                ch = str.charAt(i);
                count = 1;
            }
        }
        sb.append(ch);
        if (count > 1){
            sb.append(count);
        }
        System.out.println(sb);
    }
}
/*Дана строка вида AAAABBBCCCDDEG…, состоящая только из заглавных символов латинского алфавита.
 Напишите метод, который «свернёт» строку к виду A4B3C3D2EG, т.е. количество букв записывается цифрой.
 Если буква одна, то цифра не ставится.
 */

