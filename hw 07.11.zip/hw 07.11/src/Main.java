import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Вводите четное количество букв!");
        System.out.println("Введите первое слово: ");
        String usStr1 = scn.nextLine();
        System.out.println("Введите второе слово: ");
        String usStr2 = scn.nextLine();
        StringBuilder sb = new StringBuilder();
        if (usStr1.length() %2 != 0) {
            System.out.println("Вы ввели первое слово с нечетным количеством букв!");
        }
            if (usStr2.length() %2 != 0) {
                System.out.println("Вы ввели втрое слово с нечетным количеством букв!");
            }
        else{
                String str1 = usStr1.substring(0, usStr1.length()/2);
                String str2 = usStr2.substring(usStr2.length()/2);
                System.out.println(str1+str2);
        }
    }
}/*Введите 2 слова, воспользуйтесь сканером, состоящие из четного
количества букв (проверьте количество букв в слове).
Нужно получить слово, состоящее из первой половины первого слова
 и второй половины второго слова. Распечатать на консоль.
Например: ввод - mama, papa. Вывод – mapa*/